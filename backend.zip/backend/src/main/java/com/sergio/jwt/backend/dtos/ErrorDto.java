package com.sergio.jwt.backend.dtos;

public record ErrorDto (String message) { }
