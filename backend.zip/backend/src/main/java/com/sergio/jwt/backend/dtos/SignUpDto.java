package com.sergio.jwt.backend.dtos;

public record SignUpDto (String fullName, String email,String address, char[] password,String mobileNumber) { }
